
package com.uadb.backend.identity.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

public record LoginRequest(

        @NotBlank(message = "L'adresse email est obligatoire.")
        @Email(message = "L'adresse email est invalide.")
        String email,

        @NotBlank(message = "Le mot de passe est obligatoire.")
        String motDePasse

) {}
